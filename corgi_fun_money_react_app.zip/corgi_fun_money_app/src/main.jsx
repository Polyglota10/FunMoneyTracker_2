import React, { useEffect, useMemo, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  LineChart, Line, XAxis, YAxis, CartesianGrid
} from 'recharts'
import {
  Plus, Trash2, Heart, Target, Gift, Trophy, Search,
  CalendarDays, Sparkles, Download, Cloud, CloudOff
} from 'lucide-react'
import './styles.css'

const MONTHLY_BUDGET = 1000
const STORAGE_KEY = 'corgi-fun-money-react-v1'
const categories = ['Food & Drinks','Shopping','Entertainment','Hobbies','Beauty','Travel','Other']
const palette = ['#b58cff','#ff9fbd','#f7bd6a','#74cdb1','#83b7ff','#d7a6ff','#ffbf91']

function monthKey(date = new Date()) {
  return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}`
}

function prettyMonth(key) {
  const [y,m] = key.split('-').map(Number)
  return new Date(y,m-1,1).toLocaleDateString('en-US',{month:'long',year:'numeric'})
}

function money(v) {
  return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(v || 0)
}

function defaultState() {
  return {
    months: { [monthKey()]: [] },
    notes: {},
    goals: [],
    wishlist: [],
    rollover: false,
    achievements: []
  }
}

function loadState() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || defaultState()
  } catch {
    return defaultState()
  }
}

function App() {
  const [data, setData] = useState(loadState)
  const [selectedMonth, setSelectedMonth] = useState(monthKey())
  const [tab, setTab] = useState('dashboard')
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState('')
  const [form, setForm] = useState({
    description:'', amount:'', date:new Date().toISOString().slice(0,10), category:categories[0]
  })
  const [goalForm, setGoalForm] = useState({name:'',target:'',saved:''})
  const [wishForm, setWishForm] = useState({name:'',price:''})

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  }, [data])

  const entries = data.months[selectedMonth] || []
  const spent = entries.reduce((s,e)=>s+e.amount,0)
  const available = MONTHLY_BUDGET
  const left = available - spent

  const categoryData = useMemo(() => {
    const totals = {}
    entries.forEach(e => totals[e.category] = (totals[e.category] || 0) + e.amount)
    return Object.entries(totals).map(([name,value]) => ({name,value}))
  }, [entries])

  const trendData = useMemo(() => {
    const [y,m] = selectedMonth.split('-').map(Number)
    return Array.from({length:12},(_,i)=>{
      const d = new Date(y,m-1-(11-i),1)
      const key = monthKey(d)
      const total = (data.months[key] || []).reduce((s,e)=>s+e.amount,0)
      return {month:d.toLocaleDateString('en-US',{month:'short'}),total}
    })
  }, [data.months,selectedMonth])

  const months = useMemo(() => {
    const now = new Date()
    return Array.from({length:37},(_,i)=>{
      const d = new Date(now.getFullYear(),now.getMonth()+12-i,1)
      return monthKey(d)
    })
  }, [])

  const filteredEntries = entries
    .filter(e => (!query || e.description.toLowerCase().includes(query.toLowerCase())) && (!filter || e.category===filter))
    .sort((a,b)=>b.date.localeCompare(a.date))

  const allEntries = Object.values(data.months).flat()
  const avgMonthly = Object.keys(data.months).length
    ? Object.values(data.months).reduce((s,arr)=>s+arr.reduce((x,e)=>x+e.amount,0),0)/Object.keys(data.months).length
    : 0
  const biggest = allEntries.length ? Math.max(...allEntries.map(e=>e.amount)) : 0
  const topCategory = (() => {
    const totals = {}
    allEntries.forEach(e=>totals[e.category]=(totals[e.category]||0)+e.amount)
    return Object.keys(totals).sort((a,b)=>totals[b]-totals[a])[0] || '—'
  })()

  function addPurchase(e) {
    e.preventDefault()
    const amount = Number(form.amount)
    if (!form.description.trim() || !amount || amount <= 0) return
    const purchase = {
      id: crypto.randomUUID(),
      description: form.description.trim(),
      amount,
      date: form.date,
      category: form.category,
      createdAt: Date.now()
    }
    setData(prev => ({
      ...prev,
      months: {...prev.months, [selectedMonth]: [...(prev.months[selectedMonth] || []), purchase]}
    }))
    setForm({...form,description:'',amount:''})
  }

  function removePurchase(id) {
    setData(prev => ({
      ...prev,
      months: {...prev.months,[selectedMonth]:(prev.months[selectedMonth]||[]).filter(e=>e.id!==id)}
    }))
  }

  function addGoal(e) {
    e.preventDefault()
    if (!goalForm.name.trim() || !Number(goalForm.target)) return
    setData(prev=>({...prev,goals:[...prev.goals,{
      id:crypto.randomUUID(), name:goalForm.name.trim(),
      target:Number(goalForm.target), saved:Number(goalForm.saved||0)
    }]}))
    setGoalForm({name:'',target:'',saved:''})
  }

  function addWish(e) {
    e.preventDefault()
    if (!wishForm.name.trim() || !Number(wishForm.price)) return
    setData(prev=>({...prev,wishlist:[...prev.wishlist,{
      id:crypto.randomUUID(),name:wishForm.name.trim(),price:Number(wishForm.price)
    }]}))
    setWishForm({name:'',price:''})
  }

  function exportCSV() {
    const rows = [['Date','Description','Category','Amount'],...entries.map(e=>[e.date,e.description,e.category,e.amount])]
    const csv = rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n')
    const url = URL.createObjectURL(new Blob([csv],{type:'text/csv'}))
    const a = document.createElement('a')
    a.href=url; a.download=`fun-money-${selectedMonth}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="app-shell">
      <header className="hero">
        <div className="brand">
          <img src="./corgi.gif" className="corgi" alt="Animated corgi" />
          <div>
            <h1>Corgi Fun Money</h1>
            <p>A cozy home for your $1,000 monthly fun budget.</p>
          </div>
        </div>
        <div className="header-actions">
          <select value={selectedMonth} onChange={e=>setSelectedMonth(e.target.value)}>
            {months.map(m=><option key={m} value={m}>{prettyMonth(m)}</option>)}
          </select>
          <span className="sync-pill"><CloudOff size={16}/> Local storage</span>
        </div>
      </header>

      <nav className="tabs">
        {[
          ['dashboard','Dashboard',Heart],
          ['goals','Goals',Target],
          ['wishlist','Wishlist',Gift],
          ['history','History',CalendarDays],
          ['achievements','Achievements',Trophy]
        ].map(([id,label,Icon])=>(
          <button key={id} onClick={()=>setTab(id)} className={tab===id?'active':''}>
            <Icon size={18}/>{label}
          </button>
        ))}
      </nav>

      {tab==='dashboard' && <>
        <section className="summary-grid">
          <Stat title="Available" value={money(available)} icon={<Heart/>}/>
          <Stat title="Spent" value={money(spent)} icon={<Sparkles/>}/>
          <Stat title="Left" value={money(left)} icon={<Gift/>} danger={left<0}/>
          <Stat title="Used" value={`${Math.max(0,(spent/available)*100).toFixed(1)}%`} icon={<Target/>}/>
        </section>

        <section className="dashboard-grid">
          <div className="card purchase-card">
            <h2><Plus size={20}/> Add a purchase</h2>
            <form onSubmit={addPurchase}>
              <label>Description<input value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Dinner, books, skates..."/></label>
              <div className="two-col">
                <label>Amount<input type="number" step="0.01" min="0.01" value={form.amount} onChange={e=>setForm({...form,amount:e.target.value})}/></label>
                <label>Date<input type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></label>
              </div>
              <label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{categories.map(c=><option key={c}>{c}</option>)}</select></label>
              <button className="primary">Add spending <Heart size={17}/></button>
            </form>
            <div className="buddy-note"><img src="./heart.png"/> Your corgi is cheering you on.</div>
          </div>

          <div className="card chart-card">
            <h2>Budget overview</h2>
            <div className="chart">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={[
                    {name:'Spent',value:Math.min(spent,available)},
                    {name:spent>available?'Over budget':'Remaining',value:Math.max(spent-available,available-spent,0)}
                  ]} dataKey="value" innerRadius={72} outerRadius={105} paddingAngle={3}>
                    <Cell fill="#b58cff"/><Cell fill={spent>available?'#ef7898':'#f1e9fb'}/>
                  </Pie>
                  <Tooltip formatter={v=>money(v)}/>
                </PieChart>
              </ResponsiveContainer>
              <div className="chart-center"><strong>{money(left)}</strong><span>{left>=0?'left':'over budget'}</span></div>
            </div>
          </div>

          <div className="card chart-card">
            <h2>Spending by category</h2>
            <div className="chart">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={categoryData.length?categoryData:[{name:'No spending',value:1}]} dataKey="value" outerRadius={105}>
                    {(categoryData.length?categoryData:[{}]).map((_,i)=><Cell key={i} fill={palette[i%palette.length]}/>)}
                  </Pie>
                  <Tooltip formatter={v=>categoryData.length?money(v):'No spending yet'}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card chart-card">
            <h2>12-month trend</h2>
            <div className="chart">
              <ResponsiveContainer>
                <LineChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#eadff3"/>
                  <XAxis dataKey="month"/>
                  <YAxis tickFormatter={v=>`$${v}`}/>
                  <Tooltip formatter={v=>money(v)}/>
                  <Line type="monotone" dataKey="total" stroke="#a970ef" strokeWidth={3} dot={{r:4}}/>
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </section>

        <section className="card quick-history">
          <div className="section-head"><h2>Recent purchases</h2><button className="secondary" onClick={()=>setTab('history')}>See all</button></div>
          <PurchaseList entries={filteredEntries.slice(0,5)} remove={removePurchase}/>
        </section>
      </>}

      {tab==='goals' && <section className="page-grid">
        <div className="card">
          <h2><Target size={20}/> Add a savings goal</h2>
          <form onSubmit={addGoal}>
            <label>Goal name<input value={goalForm.name} onChange={e=>setGoalForm({...goalForm,name:e.target.value})} placeholder="Japan trip"/></label>
            <label>Target<input type="number" value={goalForm.target} onChange={e=>setGoalForm({...goalForm,target:e.target.value})}/></label>
            <label>Already saved<input type="number" value={goalForm.saved} onChange={e=>setGoalForm({...goalForm,saved:e.target.value})}/></label>
            <button className="primary">Add goal</button>
          </form>
        </div>
        <div className="goal-list">
          {data.goals.map(g=><GoalCard key={g.id} goal={g} onDelete={()=>setData(p=>({...p,goals:p.goals.filter(x=>x.id!==g.id)}))}/>)}
          {!data.goals.length && <Empty text="No savings goals yet."/>}
        </div>
      </section>}

      {tab==='wishlist' && <section className="page-grid">
        <div className="card">
          <h2><Gift size={20}/> Add a wishlist item</h2>
          <form onSubmit={addWish}>
            <label>Item<input value={wishForm.name} onChange={e=>setWishForm({...wishForm,name:e.target.value})} placeholder="Outdoor skate wheels"/></label>
            <label>Price<input type="number" value={wishForm.price} onChange={e=>setWishForm({...wishForm,price:e.target.value})}/></label>
            <button className="primary">Add item</button>
          </form>
        </div>
        <div className="goal-list">
          {data.wishlist.map(w=><div className="card wish-card" key={w.id}><div><h3>{w.name}</h3><p>{money(w.price)}</p><small>{left>=w.price?'You can afford this now.':`${Math.ceil(Math.max(w.price-left,0)/MONTHLY_BUDGET)} more month(s) at most.`}</small></div><button className="icon-btn" onClick={()=>setData(p=>({...p,wishlist:p.wishlist.filter(x=>x.id!==w.id)}))}><Trash2/></button></div>)}
          {!data.wishlist.length && <Empty text="Your wishlist is empty."/>}
        </div>
      </section>}

      {tab==='history' && <section className="card">
        <div className="section-head"><h2><CalendarDays size={20}/> Spending history</h2><button className="secondary" onClick={exportCSV}><Download size={17}/> Export CSV</button></div>
        <div className="filters">
          <div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search purchases"/></div>
          <select value={filter} onChange={e=>setFilter(e.target.value)}><option value="">All categories</option>{categories.map(c=><option key={c}>{c}</option>)}</select>
        </div>
        <PurchaseList entries={filteredEntries} remove={removePurchase}/>
      </section>}

      {tab==='achievements' && <section className="achievement-grid">
        <Achievement icon="🏅" title="Stayed under budget" detail={left>=0?'On track this month':'Try again next month'}/>
        <Achievement icon="💕" title="Purchases logged" detail={`${allEntries.length} total`}/>
        <Achievement icon="🌸" title="Average monthly spend" detail={money(avgMonthly)}/>
        <Achievement icon="✨" title="Biggest joy purchase" detail={money(biggest)}/>
        <Achievement icon="🎨" title="Favorite category" detail={topCategory}/>
      </section>}

      <footer><img src="./heart.png"/> Made for joyful, intentional spending.</footer>
    </div>
  )
}

function Stat({title,value,icon,danger}) {
  return <div className={`stat-card ${danger?'danger':''}`}><div className="stat-icon">{icon}</div><span>{title}</span><strong>{value}</strong></div>
}

function PurchaseList({entries,remove}) {
  if (!entries.length) return <Empty text="Your corgi is waiting for your next adventure."/>
  return <div className="purchase-list">{entries.map(e=><div className="purchase-row" key={e.id}>
    <div className="purchase-heart"><img src="./heart.png"/></div>
    <div className="purchase-main"><strong>{e.description}</strong><span>{e.category} · {new Date(`${e.date}T00:00:00`).toLocaleDateString()}</span></div>
    <b>{money(e.amount)}</b>
    <button className="icon-btn" onClick={()=>remove(e.id)}><Trash2 size={18}/></button>
  </div>)}</div>
}

function GoalCard({goal,onDelete}) {
  const pct = Math.min((goal.saved/goal.target)*100,100)
  return <div className="card goal-card">
    <div className="section-head"><div><h3>{goal.name}</h3><p>{money(goal.saved)} of {money(goal.target)}</p></div><button className="icon-btn" onClick={onDelete}><Trash2/></button></div>
    <div className="progress"><div style={{width:`${pct}%`}}/></div>
    <small>{pct.toFixed(0)}% complete</small>
  </div>
}

function Achievement({icon,title,detail}) {
  return <div className="card achievement"><div className="achievement-icon">{icon}</div><h3>{title}</h3><p>{detail}</p></div>
}

function Empty({text}) {
  return <div className="empty"><img src="./corgi.gif"/><p>{text}</p></div>
}

createRoot(document.getElementById('root')).render(<App/>)
